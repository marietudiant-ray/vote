-module(vote_server).
-behavior(gen_server).
-export([start_link/0,init/1,handle_call/3,handle_cast/2,handle_info/2,terminate/2,code_change/3]).
-include("vote.hrl").
-export([start/0,signin/3,signup/3,edit/3,check_result/1,vote/3,logoff/1,stop/0]).


%%============================================
%% API Functions
%%===========================================

start() ->
    gen_server:call(?MODULE,{start}).

signin(Fsmpid,Id,Password) ->
    gen_server:call(?MODULE,{signin,Fsmpid,Id,Password}).

signup(Fsmpid,Id,Password) ->
    gen_server:call(?MODULE,{signup,Fsmpid,Id,Password}).

edit(Fsmpid,Action,Information) ->
    gen_server:call(?MODULE,{edit,Fsmpid,Action,Information}).

check_result(Fsmpid) ->
    gen_server:call(?MODULE,{check_result,Fsmpid}).

vote(Fsmpid,Event,Name) ->
    gen_server:call(?MODULE,{vote,Fsmpid,Event,Name}).

logoff(Fsmpid) ->
    gen_server:call(?MODULE,{logoff,Fsmpid}).

stop() ->
    gen_server:call(?MODULE,{stop}).

%%=============================================
%% Behavior Functions
%%=============================================

start_link() ->
    gen_server:start_link({local,?MODULE},?MODULE,[],[]).

init([]) ->
    vote_db:create(?USER_TABLE,[named_table,public,set]),
    vote_db:create(?CANDIDATE_TABLE,[named_table,public,set]),
    vote_db:add(?USER_TABLE,["admin","admin","alive"]),
    vote_db:add(?CANDIDATE_TABLE,["marui",#candidate{name="marui",title="consultant"}]),
    vote_db:add(?CANDIDATE_TABLE,["junhao",#candidate{name="junhao",title="consultant"}]),
    {ok,#server{}}.

handle_call({start},_From,State) ->
    {ok,Pid}=vote_fsm:start_link([?USER_TABLE,?CANDIDATE_TABLE]),
    {reply,Pid,State};

handle_call({signin,Fsmpid,Id,Password},_From,State) ->
    Reply=vote_fsm:signin(Fsmpid,[Id,Password]),
    case Reply of
        {succeed,Id} ->
            NewState=#server{count=State#server.count+1},
            {reply,Reply,NewState};
        {not_found,Id} ->
            {reply,Reply,State};
        {wrong_password,_Count,Id} ->
            {reply,Reply,State};
        {retry,Id} ->
            {reply,Reply,State}
    end;

handle_call({signup,Fsmpid,Id,Password},_From,State) ->
    vote_fsm:signup(Fsmpid,[Id,Password]),
    Reply=vote_fsm:signin(Fsmpid,[Id,Password]),
    {reply,Reply,State};

handle_call({edit,Fsmpid,Action,Information},_From,State) ->
    {Reply,Id}=vote_fsm:verify(Fsmpid),
    case Reply of
        editing ->
   %         {ok,[Action]}=io:fread("entry: ","~s"),
   %        io:format("~p",[Action]),
            Reply2=vote_fsm:edit_candidate(Fsmpid,Action,Information),
            {reply,Reply2,State};
        no_permission ->
            Reply3={Reply,Id},
            {reply,Reply3,State}
    end;

handle_call({check_result,Fsmpid},_From,State) ->
    Reply=vote_fsm:check_result(Fsmpid),
    {reply,Reply,State};

handle_call({vote,Fsmpid,Action,Name},_From,State) ->
    {Reply,Id}=vote_fsm:vote(Fsmpid),
    case Reply of
        voting ->
            if Action =:= "vote" ->
                   Reply2=vote_fsm:vote_candidate(Fsmpid,Name),
                   {reply,Reply2,State};
               Action =:= "view" ->
                   Reply3=vote_fsm:view_candidate(Fsmpid,"view"),
                   {reply,Reply3,State}
            end;
        voted ->
            Reply4={voted,Id},
            {reply,Reply4,State};
        failed ->
            Reply5={failed,Id},
            {reply,Reply5,State}
    end;
  

handle_call({logoff,Fsmpid},_From,State) ->
    Reply=vote_fsm:stop(Fsmpid,"stop"),
    {reply,Reply,State};

handle_call({stop},_From,State) ->
    {stop,normal,State}.

handle_cast(_Msg,State) ->
    {noreply,State}.

handle_info(_Info,State) ->
    {noreply,State}.

terminate(_R,_State) ->
    vote_db:delete(?USER_TABLE),
    vote_db:delete(?CANDIDATE_TABLE),
    ok.

code_change(_OldVsn,State,_Extra) ->
    {ok,State}.


