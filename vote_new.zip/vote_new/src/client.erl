-module(client).  
-compile(export_all). 

start_client() ->  
    {ok, Socket} = gen_tcp:connect("localhost", 1234, [binary, {packet,0}]),  
    Pid = spawn(fun() -> loop1() end),  
    gen_tcp:controlling_process(Socket, Pid),  
    sendMsg(Socket).  
      
loop1() ->
    receive  
        {tcp, _Socket, Bin} ->
            Res = binary_to_term(Bin),  
            io:format("~p~n", [Res]),  
            loop1();  
        {tcp_closed,_Socket} ->
            io:format("Sorket is closed! ~n")  
        end.  
  
sendMsg(Socket) ->   
        M = io:get_line("say:"),  
        gen_tcp:send(Socket, term_to_binary([M])),  
        sendMsg(Socket).  

