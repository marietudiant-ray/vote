-module(vote_fsm).
-behavior(gen_fsm).
-include("vote.hrl").

-export([start_link/1,signin/2,signup/2,verify/1,vote/1,check_result/1,edit_candidate/3,view_candidate/2,vote_candidate/2,stop/2]).

-export([init/1,handle_event/3,handle_sync_event/4,handle_info/3,terminate/3,code_change/4,signin/3,signup/3,pending/3,edit/3,vote/3]).

%%===================================================
%% events
%%===================================================

start_link([LoginTable,CandidateTable]) ->
    gen_fsm:start_link(?MODULE,[LoginTable,CandidateTable],[]).

signin(Pid,Event) ->
    gen_fsm:sync_send_event(Pid,{signin,Event}).

signup(Pid,Event) ->
    gen_fsm:sync_send_event(Pid,{signup,Event}).

verify(Pid) ->
    gen_fsm:sync_send_event(Pid,{verify}).

vote(Pid) ->
    gen_fsm:sync_send_event(Pid,{vote}).

check_result(Pid) ->
    gen_fsm:sync_send_event(Pid,{check_result}).

edit_candidate(Pid,Event,Information) ->
    gen_fsm:sync_send_event(Pid,{edit,Event,Information}).

vote_candidate(Pid,Event) ->
    gen_fsm:sync_send_event(Pid,{vote,Event}).

view_candidate(Pid,Event) ->
    gen_fsm:sync_send_event(Pid,{view,Event}).

stop(Pid,Event) ->
    gen_fsm:sync_send_all_state_event(Pid,{stop,Event}).


%%===================================================
%% states
%%===================================================

init([LoginTable,CandidateTable]) ->
    NewState=#state{user_tab=LoginTable,candidate_tab=CandidateTable},
   {ok,signin,NewState}.

signin({signin,[Id,Password]},_From,OldState) ->
    Table=OldState#state.user_tab,
    Count=OldState#state.count,
    case vote_db:find(Table,Id) of
        [{Id,Password,_}] ->
           io:format("login succeed, welcome Mr. ~p~n",[Id]),
           NewState=OldState#state{id=Id},
           Reply={succeed,Id},
           {reply,Reply,pending,NewState};

        [{Id,_,_}] when Count >=1 ->
           io:format("Account Id: ~p, wrong password, you can try it ~p times~n",[Id,Count]),
           NewState=OldState#state{count=Count-1},
           Reply={wrong_password,Count,Id},
           {reply,Reply,signin,NewState};

        [{Id,_,_}] ->
          io:format("you failed too many times, the account blocked for 1s ~n"),
           timer:sleep(1000),
           NewState=OldState#state{count=3},
           Reply={retry,Id},
           {reply,Reply,signin,NewState};
        [] -> 
           io:format("~p not exits, please register ~n",[Id]),
            Reply={not_found,Id},
            {reply,Reply,signup,OldState}
    end.

signup({signup,[Id,Password]},_From,OldState) ->
    Table=OldState#state.user_tab,
    vote_db:add(Table,[Id,Password,"not vote"]),
    Reply={registed,Id},
    {reply,Reply,signin,OldState}.

pending(Event,_From,OldState) ->
    case Event of
        {verify} ->
            Id=OldState#state.id,
            if Id =:= "admin" ->
                   io:format("Hello ~p,you can add/delete candidate now or you can view the electors' information  ~n",[Id]),
                   Reply={editing,Id},
                   {reply,Reply,edit,OldState};
               Id =/= "admin" ->
                   io:format("Sorry ~p, you have no permission ~n",[Id]),
                   Reply={no_permission,Id},
                   {reply,Reply,pending,OldState}
            end;
        {vote} ->
            Id=OldState#state.id,
            [{_Name,_Password,Status}] = vote_db:find(?USER_TABLE,Id),
            if Status =:= "not vote" ->
                   Reply={voting,Id},
                   {reply,Reply,vote,OldState};
               Status =:= "voted" ->
                   io:format("Sorry Mr. ~p, you have already voted.~n",[Id]),
                   Reply={voted,Id},
                   {reply,Reply,pending,OldState};
               Status =:= "alive" ->
                   io:format("Sorry Mr. ~p, you can't vote ~n",[Id]),
                   Reply={failed,Id},
                   {reply,Reply,pending,OldState}
            end;
        {check_result} ->
            Candidate_tab=OldState#state.candidate_tab,
            List=vote_db:traverse(Candidate_tab),
            Reply=traverse_candidate_after(List," "),
           % Reply={checked,OldState#state.id},
            {reply,Reply,pending,OldState}
    end.

edit({edit,Action,Information},_From,OldState) ->
    Table=OldState#state.candidate_tab,
    case Action of
        "add" -> 
     %      {ok,[Name,Title]}=io:fread("entry the name and title of candidate \n", "~s ~s"),
           [Name,Title,_Nothing]=Information,
           Candidate1=#candidate{name=Name,title=Title},
           vote_db:add(Table,[Name,Candidate1]),
           Reply={added,OldState#state.id},
           {reply,Reply,pending,OldState};
        "delete" ->
     %      {ok,[Name]}=io:fread("entry the name of candidate who you wanna delete \n","~s"),
            io:format("~p",[Information]),
            [Name,_Nothing]=Information,
            ets:delete(Table,Name),
            Reply={deleted,OldState#state.id},
            {reply,Reply,pending,OldState};
        "check"->
            User_tab=OldState#state.user_tab,
            List=vote_db:traverse(User_tab),
            Reply={traverse_user(List," "),OldState#state.id},
    %        Reply={checked,OldState#state.id},
            {reply,Reply,pending,OldState};
         _ ->
            Reply={wrong_order,OldState#state.id},
            {reply,Reply,pending,OldState}
    end.

vote(Event,_From,OldState) ->
    case Event of
        {view,_} -> 
            Candidate_tab=OldState#state.candidate_tab,
            List=vote_db:traverse(Candidate_tab),
            Reply={traverse_candidate_before(List," "),OldState#state.id},
         %   Reply={viewing,OldState#state.id},
            {reply,Reply,pending,OldState};
        {vote,Name} ->
            io:format("choose your favoriate candidate~n"),
   %         {ok,[Name]}=io:fread("entry:","~s"),
            Table=OldState#state.candidate_tab,
            case vote_db:find(Table,Name) of
                [{Name,Candidate}] ->
                    Vote=Candidate#candidate.vote+1,
                    vote_db:add(?CANDIDATE_TABLE,[Name,#candidate{name=Candidate#candidate.name,title=Candidate#candidate.title,vote=Vote}]),
                    [{Id,Password,_Status}]=vote_db:find(?USER_TABLE,OldState#state.id),
                    vote_db:add(?USER_TABLE,[Id,Password,"voted"]),
                    Reply={voting,OldState#state.id},
                    {reply,Reply,pending,OldState};
                [] ->
                    io:format("candidate not exits"),
                    Reply={voted_failed,OldState#state.id},
                    {reply,Reply,pending,OldState}
            end
    end.


handle_event({stop,_Event},_StateName,OldState) ->
    {stop,normal,OldState}.

handle_sync_event({stop,_Event},_From,_StateName,OldState) ->
    Reply={stopped,OldState#state.id},
    {stop,normal,Reply,OldState}.
    

handle_info(Info,State,Data)  ->
    unexpected(Info,State),
    {next_state,State,Data}.

terminate(_Reason,_State,_Data) ->
    ok.

code_change(_Vsn,State,Data,_Extra) ->
    {ok,State,Data}.
%%==================================================
%% private functions
%%==================================================

unexpected(Msg,State) ->
    io:format("~p received unknown event ~p while in state ~p~n",[self(),Msg,State]).

traverse_candidate_before(List,String) ->          
    case List of
        [{_Name,Candidate}|T] ->
          %  io:format("Mr. ~p, title: ~p~n",[Candidate#candidate.name,Candidate#candidate.title]),
            A=lists:append(String,lists:append(["Mr.",Candidate#candidate.name,", title: ",Candidate#candidate.title," ; "])),
            traverse_candidate_before(T,A);
        [] ->
            list:append(String,"please vote")
    end.

traverse_candidate_after(List,String) ->
    case List of
        [{_Name,Candidate}|T] ->
          %  io:format("Mr. ~p,title: ~p, vote: ~p ~n",[Candidate#candidate.name,Candidate#candidate.title,Candidate#candidate.vote]),
            A=lists:append(String,lists:append(["Mr.",Candidate#candidate.name,", title: ",Candidate#candidate.title,", vote: ",integer_to_list(Candidate#candidate.vote)," ; "])),
            traverse_candidate_after(T,A);
        [] ->
            lists:append(String,"end")
    end.

traverse_user(List,String) ->
    case List of 
        [{Name,_Password,Status}|T] ->
          %  io:format("Id: ~p, Status: ~p ~n",[Name,Status]),
            A=lists:append(String,lists:append(["Mr.",Name,", Status: ",Status," ; "])),
            traverse_user(T,A);
        [] ->
            lists:append(String,"end")
    end.


