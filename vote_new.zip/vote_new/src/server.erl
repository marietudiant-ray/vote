-module(server).  
-compile(export_all).  

start_server() ->  
    vote_server:start_link(),  
    case gen_tcp:listen(1234, [binary, {packet,0}, {active,true},{reuseaddr,true}]) of  
        {ok, ListenSocket} ->  
            spawn(fun()-> connect(ListenSocket) end);       
        {error, Reason} ->  
            io:format("~p~n", [Reason])  
    end.  
  
connect(ListenSocket) ->  
    case gen_tcp:accept(ListenSocket) of    
        {ok,Socket} -> 
            Pid=vote_server:start(),
            gen_tcp:send(Socket,term_to_binary(["hello,signin please."])),
            spawn(fun() -> connect(ListenSocket) end),   
            loop(Socket,Pid);  
        {error, Reason} ->  
            io:format("~p~n", [Reason])  
    end.  
  
loop(Socket,Pid) ->  
    receive  
        {tcp, Socket, Bin} ->  
            [Msg] = binary_to_term(Bin),
            List=string:tokens(Msg," "),
            case hd(List) of

                "signin" -> 
                    [Id,Password]=tl(List),
                    Reply=vote_server:signin(Pid,Id,lists:delete($\n,Password)),
                    case Reply of
                        {succeed,Id} ->
                            Message="login succeed, welcom Mr."++Id,
                            gen_tcp:send(Socket,term_to_binary([Message]));
                        {wrong_password,Count,Id} ->
                            Message=lists:append(["Account Id:",Id,", wrong password, you can try it ",integer_to_list(Count)," times"]),
                            gen_tcp:send(Socket,term_to_binary([Message]));
                        {not_found,Id} ->
                            Message=lists:append([Id," not exits, please register"]),
                            gen_tcp:send(Socket,term_to_binary([Message]));
                        {retry,Id} ->
                            Message="you failed too many times, the account blocked for 1s",             
                           gen_tcp:send(Socket,term_to_binary([Message]))
                    end;

                "signup" ->
                    [Id,Password]=tl(List),
                    vote_server:signup(Pid,Id,lists:delete($\n,Password)),
                    Message="Now you have registed Mr."++Id,
                    gen_tcp:send(Socket,term_to_binary([Message]));
                
                "result" ->
                    Message=vote_server:check_result(Pid),
                    gen_tcp:send(Socket,term_to_binary([Message]));

                "edit" ->
                    [Action|Information]=tl(List),
           %         io:format("~p",[lists:delete($\n,Action)]), 
           %         io:format("~p   ~p",[Action,Information]),     
                   {Message,Id}=vote_server:edit(Pid,Action,Information),
                    case Message of
                        no_permission ->
                            NewMessage=lists:append(["Sorry Mr.",Id,", you have no permission"]),
                            gen_tcp:send(Socket,term_to_binary([NewMessage]));
                        _ ->
                            gen_tcp:send(Socket,term_to_binary([Message]))
                    end;

                
                "vote" ->
                    [Action|Information]=tl(List),
                    [Name,_Nothing]=Information,
                    {Message,_Id}=vote_server:vote(Pid,Action,Name),
                    case Message of
                        voting ->
                             gen_tcp:send(Socket,term_to_binary(["succeed voted"]));
                        voted_failed ->
                             gen_tcp:send(Socket,term_to_binary(["candidate not exits"]));
                        voted ->
                    gen_tcp:send(Socket,term_to_binary(["you have already voted"]));
                        failed ->
                    gen_tcp:send(Socket,term_to_binary(["sorry you can't vote"]))
                    end;

                "logoff" ->
                    vote_server:logoff(Pid),
                    gen_tcp:send(Socket,term_to_binary(["bye bye"])),
                    gen_tcp:close(Socket)
            end,
            loop(Socket,Pid);  
        {tcp_closed, Socket} ->  
            io:format("Server socket closed ~n")  
    end.  

stop() ->
    vote_server:stop().
