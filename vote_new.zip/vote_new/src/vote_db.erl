-module(vote_db).
-export([create/2,find/2,add/2,delete/1,delete/2,traverse/1]).


create(Tab_Name,Mode) ->
    ets:new(Tab_Name,Mode).

find(Tab_Name,Id) -> 
    ets:lookup(Tab_Name,Id).

add(Tab_Name,[Id,Password]) ->
    ets:insert(Tab_Name,{Id,Password});

add(Tab_Name,[Id,Password,Status]) ->
    ets:insert(Tab_Name,{Id,Password,Status}).

delete(Tab_Name) ->
    ets:delete(Tab_Name).

delete(Tab_Name,Name) ->
    ets:delete(Tab_Name,Name).

traverse(Tab_Name) ->
    ets:tab2list(Tab_Name).
