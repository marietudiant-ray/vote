#!/bin/bash

mkdir ./src/
mkdir ./priv/
mkdir ./include/
mkdir ./ebin/
